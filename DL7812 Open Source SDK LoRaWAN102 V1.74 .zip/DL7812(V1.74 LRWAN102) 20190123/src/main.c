
/* USER CODE BEGIN Includes */
#include "mcu_head.h"
#include "board.h"
#include "SEGGER_RTT.h"

/* USER CODE END Includes */


#define XT              1
#define LFRC            2


/* USER CODE BEGIN PV */
/* Private define ---------------------------------------------------------*/
#define UART_CMD	1   //Comment it if don't use
#define RTT_Debug	1   //Comment it if don't use

#define SPI_PIN_MOSI                                10
#define SPI_PIN_MISO                                9
#define SPI_PIN_SCLK                                8
#define SPI_PIN_NSS                                	15
#define RF_RXTX_PIN                               	1
#define RF_FEMCTX_PIN                               0
#define RF_NRST_PIN                               	11
#define RF_DIO0_Pin                               	12
#define RF_DIO1_Pin                               	16
#define RF_DIO2_Pin                               	14
#define RF_DIO3_Pin                               	17
#define RF_DIO4_Pin                               	18
#define RF_DIO5_Pin                               	29
#define CHECK_IO0_Pin                               19
#define CHECK_IO1_Pin                               34
#define CHECK_IO2_Pin                               47

#define RF_ON_Pin                               	33 		//����

#define XS508_SCL_Pin                               24
#define XS508_SDA_Pin                               25


/* Private variables ---------------------------------------------------------*/
int32_t i32Module = AM_BSP_UART_PRINT_INST;

unsigned int ctimer_cnt = 0;
uint8_t TmsFlag = 0;
uint8_t T10msFlag = 0;
uint8_t T100msFlag = 0;
uint8_t TsFlag = 0;
uint8_t UartRxFlag = 0;
uint8_t UartRxData;


/*
 * LRWAN String
 */
const char* ISMBandStrings[] =
{
    "EU863_870",
    "US902_928",
    "AS923",
    "CN779_787",
    "CN470_510",
    "EU433",
    "CUSTOMIZE",
};

const char* ClassStrings[] =
{
    "CLASS A",
    "",
    "CLASS C",
};

const char* ActivationStrings[] =
{
    "ABP",
    "OTAA",
};

const char* PowerStrings[] =
{
    "20dBm",
    "14dBm",
    "11dBm",
    "8dBm",
    "5dBm",
    "2dBm",
};

const char* ConfirmStrings[] =
{
    "CONFIRM",
    "UNCONFIRM",
};

/*
 * LRWAN Var
 */
struct LRWAN_Var
{
    uint16_t uplinkcycle;   //unit:s
}LRWAN_Var = 
{
    20,

};


/* USER CODE END PV */

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void debug_printf(char *fmt, ...);
void Delay_Ms(uint16_t n);
void USERProgram_Handler(void);
void AllBusiness_Handler_100ms(void);


/* USER CODE END PFP */


//*****************************************************************************
//
// Timer Interrupt Service Routine (ISR)
//
//*****************************************************************************
void am_ctimer_isr(void)
{
    uint32_t ui32Status;
    //
    // Clear TimerA0 Interrupt (write to clear).
    //
    ui32Status = am_hal_ctimer_int_status_get(true); //AM_REGn(CTIMER, 0, INTSTAT);	//
    am_hal_ctimer_int_clear(ui32Status);

    if(AM_HAL_CTIMER_INT_TIMERA0 & ui32Status)
    {
        am_hal_ctimer_int_clear(AM_HAL_CTIMER_INT_TIMERA0);

        SleepTimerAwake();
    }
    if(AM_HAL_CTIMER_INT_TIMERA1 & ui32Status)
    {
        am_hal_ctimer_int_clear(AM_HAL_CTIMER_INT_TIMERA1);
        ctimer_cnt++;
        if(ctimer_cnt >= 60000)
        {
            ctimer_cnt = 0;
        }

        if(ctimer_cnt % 10 == 0)
        {
            T10msFlag = 1;
        }
        if(ctimer_cnt % 100 == 0)
        {
            T100msFlag = 1;
        }
        if(ctimer_cnt % 1000 == 0)
        {
            TsFlag = 1;
        }

        TmsFlag = 1;

    }

}


//*****************************************************************************
//
// uart Interrupt Service Routine (ISR)
//
//*****************************************************************************
void am_uart_isr(void)
{
    int32_t i32Module = AM_BSP_UART_PRINT_INST;
    //
    // Clear TimerA0 Interrupt (write to clear).
    //
    uint32_t status;

    status = am_hal_uart_int_status_get(i32Module, false);

    if(status & AM_HAL_UART_INT_RX)
    {
        am_hal_uart_int_clear(i32Module, AM_HAL_UART_INT_RX);

        UartRxData = AM_REGn(UART, 0, DR);
        UartRxFlag = 1;

    }

    am_hal_uart_service_buffered(i32Module, status);
    am_hal_uart_int_clear(i32Module, status);
}


//*****************************************************************************
//
// Main
//
//*****************************************************************************
int main(void)
{
    uint16_t lorawanflag;

    debug_printf("- Product Info:\n\tName\t%s\n\tVers\t%s\n\tDate\t%s\n\tComp\tMaxiiot Ltd.\n\tEdit\tBy Michael\r\n",DeviceName,DeviceRev,DeviceRevDate);

    // Set the clock frequency.
    am_hal_clkgen_sysclk_select(AM_HAL_CLKGEN_SYSCLK_MAX);

    // Initialize the BSP.
    am_bsp_low_power_init();

    io_init ();

    timerA0_init();		//For sleep timing
    timerA1_init();		//For loranwan timing

    // Initialize the printf interface for UART output.
    am_util_stdio_printf_init((am_util_stdio_print_char_t)am_bsp_uart_string_print);
    uart_init(i32Module);
    uart_enable(i32Module);
    
    // Enable the timer Interrupt.
    am_hal_ctimer_int_enable(AM_HAL_CTIMER_INT_TIMERA0);
    am_hal_ctimer_int_enable(AM_HAL_CTIMER_INT_TIMERA1);

    // Enable the timer interrupt in the NVIC.
    am_hal_interrupt_enable(AM_HAL_INTERRUPT_CTIMER);
    am_hal_interrupt_master_enable();

    // Enable the timer.
    am_hal_ctimer_start(1, AM_HAL_CTIMER_TIMERA);		//For loranwan timing

    /* USER CODE BEGIN  */

    am_hal_gpio_out_bit_clear(RF_ON_Pin);			//RF enable

    Delay_Ms(1000);
    at_printf("\r\nBooting...");
    at_printf("\r\nDevName: %s",DeviceName);
    at_printf("\r\nVersion: %s",DeviceRev);
    at_printf("\r\nLoraMac: 1.0.2");
    at_printf("\r\nDate:    %s",DeviceRevDate);
    at_printf("\r\nComp:    Maxiiot Ltd.");
    at_printf("\r\nOK\r\n");

    debug_printf("- System Init: Ok\r\n");

    /* USER CODE END  */

    while (1)
    {
        /* USER CODE BEGIN  */
        
        /* LRWAN CODE BEGIN */
        LoRaMAC_Process();	
        /* LRWAN CODE END */

        if(TmsFlag)
        {
            TmsFlag = 0;
            /* LRWAN CODE BEGIN */
            LoRaWanRTCProgress();	
            /* LRWAN CODE END */
        }

        if(UartRxFlag)
        {
            UartRxFlag = 0;
#if defined(UART_CMD)
            /* LRWAN CODE BEGIN */
            UART_ATCommand_Process(UartRxData);
            /* LRWAN CODE END */
#endif
        }

        /* USER CODE END  */
        
        /* LRWAN USER CODE BEGIN */
        lorawanflag = LoRaWanCheckFlag();
        if(lorawanflag&(1<<TXDONE))
        {
            debug_printf("LoRaWanCheckFlag:%s\r\n","TXDONE");
        }
        else if(lorawanflag&(1<<RXDONE))
        {
            //receive a app downlink frame from lora server 
            debug_printf("LoRaWanCheckFlag:%s\r\n","RXDONE");
            debug_printf("downlink len:%d\r\n",LoRaWanRxInfo.size);
            debug_printf("downlink frame:%s\r\n",LoRaWanRxInfo.buf);
            debug_printf("downlink port:%d\r\n",LoRaWanRxInfo.port);
            debug_printf("downlink rssi:%d,snr:%d\r\n",LoRaWanRxInfo.rssi,LoRaWanRxInfo.snr);
        }
        else if(lorawanflag&(1<<OTAA_JOINOK))
        {
            debug_printf("LoRaWanCheckFlag:%s\r\n","OTAA_JOINOK");
        }
        else if(lorawanflag&(1<<CMD_RECEIVE))
        {
            debug_printf("LoRaWanCheckFlag:%s\r\n","CMD_RECEIVE");
        }
        else if(lorawanflag&(1<<ACK_RECEIVE))
        {
            debug_printf("LoRaWanCheckFlag:%s\r\n","ACK_RECEIVE");
        }
        else if(lorawanflag&(1<<ACK_UNRECEIVE))
        {
            debug_printf("LoRaWanCheckFlag:%s\r\n","ACK_UNRECEIVE");
        }
        /* LRWAN USER CODE END */
        
        if(gpioisrflag)
        {
            gpioisrflag = 0;
            SleepTimerAwake();
        }
        
        if(ATSleepFlag)
        {
            if(SX1276.Settings.State==RF_IDLE)
            {
                EnterSleepMode();
                ATSleepFlag = 0;
            }
        }
        
        //User secondary development
        USERProgram_Handler();

    }
}


/***********************User Code Begin***************************/


//-----------------------LoRaWan Function begin------------------------------//

void MOSI_HIGH(void)
{
    am_hal_gpio_out_bit_set(SPI_PIN_MOSI);
}

void MOSI_LOW(void)
{
    am_hal_gpio_out_bit_clear(SPI_PIN_MOSI);
}

uint8_t MISO_Read(void)
{
    return am_hal_gpio_input_bit_read(SPI_PIN_MISO);
}

void SCLK_HIGH(void)
{
    am_hal_gpio_out_bit_set(SPI_PIN_SCLK);
}

void SCLK_LOW(void)
{
    am_hal_gpio_out_bit_clear(SPI_PIN_SCLK);
}

void NSS_HIGH(void)
{
    am_hal_gpio_out_bit_set(SPI_PIN_NSS);
}

void NSS_LOW(void)
{
    am_hal_gpio_out_bit_clear(SPI_PIN_NSS);
}

void RXTX_HIGH(void)
{
    //High frequency module is high send and low receive
    //am_hal_gpio_out_bit_set(RF_FEMCTX_PIN);

    //Low frequency module is low send and high receive
    am_hal_gpio_out_bit_clear(RF_FEMCTX_PIN);
}

void RXTX_LOW(void)
{
    //High frequency module is high send and low receive
    //am_hal_gpio_out_bit_clear(RF_FEMCTX_PIN);

    //Low frequency module is low send and high receive
    am_hal_gpio_out_bit_set(RF_FEMCTX_PIN);
}

uint8_t Read_DIO0(void)
{
    return am_hal_gpio_input_bit_read(RF_DIO0_Pin);
}

uint8_t Read_DIO1(void)
{
    return am_hal_gpio_input_bit_read(RF_DIO1_Pin);
}

uint8_t Read_DIO2(void)
{
    return am_hal_gpio_input_bit_read(RF_DIO2_Pin);
}

uint8_t Read_DIO3(void)
{
    return am_hal_gpio_input_bit_read(RF_DIO3_Pin);
}

uint8_t Read_DIO4(void)
{
    return am_hal_gpio_input_bit_read(RF_DIO4_Pin);
}

uint8_t Read_DIO5(void)
{
    return am_hal_gpio_input_bit_read(RF_DIO5_Pin);
}


char Printf_BUF[1000];
void lora_printf(char *fmt, ...)
{
    if(TempLoraConfig.Debug)
    {
        va_list ap;
        va_start(ap, fmt);
        vsprintf((char *)Printf_BUF, fmt, ap);
        va_end(ap);
        am_util_stdio_printf(Printf_BUF);
    }
}

void at_printf(char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsprintf((char *)Printf_BUF, fmt, ap);
    va_end(ap);
    am_util_stdio_printf(Printf_BUF);
}

void debug_printf(char *fmt, ...)
{
#if defined(RTT_Debug)
    va_list ap;
    va_start(ap, fmt);
    vsprintf((char *)Printf_BUF, fmt, ap);
    va_end(ap);
    SEGGER_RTT_printf(0,Printf_BUF);
#endif
}


void RFRST_ON(void)
{
    //Low reset
    am_hal_gpio_out_bit_clear(RF_NRST_PIN);
}

void RFRST_OFF(void)
{
    am_hal_gpio_out_bit_set(RF_NRST_PIN);
}

void FLASH_Program(uint32_t Address, uint32_t Data)
{
    static uint32_t ui32Data[1], Addr;

    ui32Data[0] = Data;
    Addr = Address;
    am_hal_flash_program_main(AM_HAL_FLASH_PROGRAM_KEY, ui32Data, (uint32_t *)Addr, 1);
}

void FLASH_Erase_ADDRInPage(uint32_t Adrr)
{
    am_hal_flash_page_erase(AM_HAL_FLASH_PROGRAM_KEY,
                            AM_HAL_FLASH_ADDR2INST(Adrr),
                            AM_HAL_FLASH_ADDR2PAGE(Adrr));
}

void MCU_RESET(void)
{
    am_hal_reset_por();
}

void BoardGetUniqueId( uint8_t *id )
{
    uint8_t i;

	for(i=0;i<8;i++)
	{
		id[i] = XS508_DAT[8+i];
	}
}

void SleepTimerStart( uint32_t Period_S )
{
    am_hal_ctimer_clear(0, AM_HAL_CTIMER_TIMERA);
    am_hal_ctimer_period_set(0, AM_HAL_CTIMER_TIMERA, Period_S,
                             (Period_S >> 1));
    am_hal_ctimer_start(0, AM_HAL_CTIMER_TIMERA);
}

void SleepTimerStop( void )
{
    am_hal_ctimer_stop(0, AM_HAL_CTIMER_TIMERA);
}

void LoRaWanTimerStart( void )
{
    am_hal_ctimer_clear(1, AM_HAL_CTIMER_TIMERA);
    am_hal_ctimer_start(1, AM_HAL_CTIMER_TIMERA);
}

void LoRaWanTimerStop( void )
{
    am_hal_ctimer_stop(1, AM_HAL_CTIMER_TIMERA);
}

void EnterSleepMode( void )
{
    //disable uart
    am_bsp_pin_disable(COM_UART_TX);
    am_bsp_pin_disable(COM_UART_RX);
    am_hal_uart_pwrctrl_disable(i32Module);
    am_hal_uart_clock_disable(i32Module);
    am_hal_uart_disable(i32Module);

    am_hal_gpio_out_bit_set(RF_ON_Pin);			//disable RF crystal oscillator

	am_hal_gpio_pin_config(20, AM_HAL_GPIO_LOW_DRIVE);  //Jtag SWDCK  down pull
	am_hal_gpio_pin_config(21, AM_HAL_GPIO_PULLUP);  //Jtag SWDIO  up pull

    am_hal_gpio_out_bit_set(SPI_PIN_MOSI);
    am_hal_gpio_out_bit_set(SPI_PIN_MISO);
    am_hal_gpio_out_bit_set(SPI_PIN_SCLK);
    am_hal_gpio_out_bit_set(SPI_PIN_NSS);

    am_hal_gpio_out_bit_set(XS508_SCL_Pin);
    am_hal_gpio_out_bit_set(XS508_SDA_Pin);

    am_hal_gpio_out_bit_set(RF_DIO0_Pin);
    am_hal_gpio_out_bit_set(RF_DIO1_Pin);
    am_hal_gpio_out_bit_set(RF_DIO2_Pin);
    am_hal_gpio_out_bit_set(RF_DIO3_Pin);
    am_hal_gpio_out_bit_set(RF_DIO4_Pin);
    am_hal_gpio_out_bit_set(RF_DIO5_Pin);
    
    LoRaWanTimerStop();
    
    intermit_io_init();

    am_hal_sysctrl_sleep(AM_HAL_SYSCTRL_SLEEP_DEEP);
}

void SleepTimerAwake(void)
{

    am_hal_gpio_int_disable(AM_HAL_GPIO_BIT(36));// Enable the GPIO interrupt.
    am_hal_interrupt_disable(AM_HAL_INTERRUPT_GPIO);// Enable GPIO interrupts to the NVIC.
    am_hal_interrupt_master_disable();
    
    //restart uart
    am_bsp_pin_enable(COM_UART_TX);
    am_bsp_pin_enable(COM_UART_RX);
    am_hal_uart_pwrctrl_enable(i32Module);
    am_hal_uart_clock_enable(i32Module);
    am_hal_uart_enable(i32Module);

    am_hal_gpio_out_bit_clear(RF_ON_Pin);			//enable RF crystal oscillator

    LoRaWanTimerStart();
    Delay_Ms(100);
    at_printf("AWAKE\r\n");
    
}

//------------------XS508 analog I2C pin function-----------------------
void I2C_SCL_H(void)
{
    am_hal_gpio_out_bit_set(XS508_SCL_Pin);
}

void I2C_SCL_L(void)
{
    am_hal_gpio_out_bit_clear(XS508_SCL_Pin);
}

void I2C_SDA_H(void)
{
    am_hal_gpio_out_bit_set(XS508_SDA_Pin);
}

void I2C_SDA_L(void)
{
    am_hal_gpio_out_bit_clear(XS508_SDA_Pin);
}

uint8_t I2C_SDA_Read(void)
{
    return am_hal_gpio_input_bit_read(XS508_SDA_Pin);	//Use input to read open-drain output pins in Apollo MCU
}

//-------------------------LoRaWan Function end--------------------------//

void Delay_Ms(uint16_t n)
{
    uint16_t i, j;

    for(i = 0; i < n; i++)
    {
        for(j = 0; j < 110; j++);
    }
}


/*
 * Secondary development function
 */
void USERProgram_Handler(void)
{
    static uint8_t state = 0;

    if(state == 0)
    {
        uint16_t ChMask[6] = {0x00ff,0x0000,0x0000,0x0000,0x0000,0x0000};
        
        //Custom configuration
        //Comment them if you don't need

        //choose ism band
        LoRaWanSetISMBand( CN470_510 );
        
        //choose class a or class c
        LoRaWanSetClass( CLASS_A );

        //choose activation way
        LoRaWanSetAutoJoinMode( OTAA_JOIN );

        //choose tx channel (default ch0--ch7)
        LoRaWanSetChannelMask( ChMask );

        //choose rf tx power
        LoRaWanSetTxPower(0);

        //choose frame type
        LoRaWanSetFrameType( Confrim );
        
        //choose channel port (port>0)
        LoRaWanSetSendPort(2);

        //enable lorawan debug log or not
        TempLoraConfig.Debug= false;
        
        state = 1;
    }
    else if(state == 1)
    {
        //Show default configuration

        uint8_t i = 0;
        uint8_t DevEUI[8];

        LoRaWanGetDeviceEUI(DevEUI);
        
        debug_printf("> LoRaWAN Configuration Parameter\r\n");
        debug_printf("  DevEUI:");
        for(i=0;i<8;i++)
        {
            debug_printf("%02x",DevEUI[i]);
        }
        debug_printf("\r\n");
        debug_printf("  AppEUI:");
        for(i=0;i<8;i++)
        {
            debug_printf("%02x",TempLoraConfig.AppEui[i]);
        }
        debug_printf("\r\n");
        debug_printf("  AppKey:");
        for(i=0;i<16;i++)
        {
            debug_printf("%02x",TempLoraConfig.AppKey[i]);
        }
        debug_printf("\r\n");
        debug_printf("  AppSKey:");
        for(i=0;i<16;i++)
        {
            debug_printf("%02x",TempLoraConfig.AppSKey[i]);
        }
        debug_printf("\r\n");
        
        debug_printf("  NwkSKey:");
        for(i=0;i<16;i++)
        {
            debug_printf("%02x",TempLoraConfig.NwkSKey[i]);
        }
        debug_printf("\r\n");

        debug_printf("  DevAddr:0x%04x\r\n",TempLoraConfig.DevAddr);
        debug_printf("  CLASS Tpye:%s\r\n",ClassStrings[TempLoraConfig.CurClass]);
        debug_printf("  Activation:%s\r\n",ActivationStrings[TempLoraConfig.ActivationWay]);
        debug_printf("  ISMBand:%s\r\n",ISMBandStrings[TempLoraConfig.ISMBand]);
        debug_printf("  Channel Mask:");
        for(i=0;i<6;i++)
        {
            debug_printf("%04x ",TempLoraConfig.ChannelMask[i]);
        }
        debug_printf("\r\n");
        debug_printf("  Tx power:%s\r\n",PowerStrings[TempLoraConfig.TXPower]);
        debug_printf("  Frame type:%s\r\n",ConfirmStrings[TempLoraConfig.ConfFlag]);
        debug_printf("  ADR:%d\r\n",TempLoraConfig.ADR);
        debug_printf("  Send port:%d\r\n",TempLoraConfig.SendPort);
        debug_printf("<\r\n");
        
        state = 2;
    }
    else{
        //running program

        if(T100msFlag)
        {
            T100msFlag = 0;

            AllBusiness_Handler_100ms();
        }

    }
}

void Uplink_Handler_1s(void)
{
    static uint8_t count = 0;
    
    count++;
    if(count>199)
        count = 0;
    
    if(LoRaWanGetAutoJoinMode()==OTAA_JOIN)
    {
        uint8_t joinstate = 0;
        
        //Check OTAA Activation
        joinstate = LoRaGetJoinState();
        
        if(joinstate == 1) // activate ok
        {
            //uplink example
            
            if(count%LRWAN_Var.uplinkcycle == 3)
            {
                //uint16_t ChMask[6] = {0x00ff,0x0000,0x0000,0x0000,0x0000,0x0000};
                
                //choose tx channel (default ch0--ch7)   
                //Prevent the server from modifying the channel
                //LoRaWanSetChannelMask( ChMask );
                
                //send an app uplink frame to lora server
                if(!LoRaWanSendBuf(CONFIRMED, "hello", 5, 2))
                {
                    //send ok
                }
            }
        }
        else if(joinstate == 2) // Trying to activate
        {
            count = 0;
        }
        else if(joinstate == 0) // activate fail
        {
            debug_printf("\r\n- activate fail\r\n");

            //comment it if you don't want to try activating again
            debug_printf("\r\n- try activating again\r\n");
            LoRaWanSetAutoJoinMode( OTAA_JOIN );
        }
    }
    else{
        //ABP Activation
        if(count%LRWAN_Var.uplinkcycle == 1)
        {
            //send an app uplink frame to lora server
            if(!LoRaWanSendBuf(CONFIRMED, "hello", 5, 2))
            {
                //send ok
            }
        }
    }

}


/*
 * All business tasks handker
 */
void AllBusiness_Handler_100ms(void)
{
    static uint16_t count = 0;
    uint8_t remainder = 0;
    

    count++;
    if(count >= 1000)
        count = 0;

    //Generate 10 one second time slices and assign them to 10 tasks
    remainder = count % 10;

    switch(remainder)
    {
    case 0:
        Uplink_Handler_1s();
        break;
    case 1:

        break;
    case 2:
        
        break;
    case 3:
   
        break;
    }

}






/***********************User Code End***************************/






