#ifndef __define_H
#define __define_H

#include "am_mcu_apollo.h"
#include "am_bsp.h"

//ģ��SPI
#define SPI_CS    am_hal_gpio_pin_config(15, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)     //	PB4 OUTPUT
#define SPI_CLK   am_hal_gpio_pin_config(8, AM_HAL_PIN_OUTPUT) //PB8 OUTPUT
#define SPI_MOSI  am_hal_gpio_pin_config(10, AM_HAL_PIN_OUTPUT) //PB10 OUTPUT
#define SPI_MISO  am_hal_gpio_pin_config(9, AM_HAL_PIN_INPUT|AM_HAL_GPIO_LOW_DRIVE) //PB9 INPUT

//RF IO init
#define RF_RXTX     am_hal_gpio_pin_config(1, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)     //PB1 OUTPUT
#define RF_NRST     am_hal_gpio_pin_config(11, AM_HAL_PIN_OUTPUT)     //PB11 OUTPUT
#define RF_FEM_CTX  am_hal_gpio_pin_config(0, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP) //PB0OUTPUT

// IO Interrupt
#define RF_DIO0     am_hal_gpio_pin_config(12, AM_HAL_GPIO_INPUT|AM_HAL_GPIO_LOW_DRIVE)    
#define RF_DIO1     am_hal_gpio_pin_config(16, AM_HAL_GPIO_INPUT|AM_HAL_GPIO_LOW_DRIVE) 
#define RF_DIO2     am_hal_gpio_pin_config(14, AM_HAL_GPIO_INPUT|AM_HAL_GPIO_LOW_DRIVE) 
#define RF_DIO3     am_hal_gpio_pin_config(17, AM_HAL_GPIO_INPUT|AM_HAL_GPIO_LOW_DRIVE)   
#define RF_DIO4     am_hal_gpio_pin_config(18, AM_HAL_GPIO_INPUT|AM_HAL_GPIO_LOW_DRIVE)     
#define RF_DIO5     am_hal_gpio_pin_config(29, AM_HAL_GPIO_INPUT|AM_HAL_GPIO_LOW_DRIVE)

#define RF_ON     am_hal_gpio_pin_config(33, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)

#define XS508_SCL     am_hal_gpio_pin_config(24, AM_HAL_PIN_OUTPUT) 
#define XS508_SDA     am_hal_gpio_pin_config(25, AM_HAL_PIN_OPENDRAIN) 

// IO Init
//#define CHECK_IO0     am_hal_gpio_pin_config(19, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)    
//#define CHECK_IO1     am_hal_gpio_pin_config(34, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP) 
//#define GPIO45     am_hal_gpio_pin_config(15, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP) 
//#define GPIO46     am_hal_gpio_pin_config(46, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)   
//#define CHECK_IO2     am_hal_gpio_pin_config(47, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)     
//#define GPIO48     am_hal_gpio_pin_config(48, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)
//#define GPIO49     am_hal_gpio_pin_config(49, AM_HAL_PIN_OUTPUT|AM_HAL_GPIO_PULLUP)


extern uint8_t gpioisrflag;

void io_init (void);
void intermit_io_init (void);
void timerA1_init(void);
void am_gpio_isr(void);
void uart_init(int32_t i32Module);
void uart_enable(int32_t i32Module);
void uart_disable(int32_t i32Module);
void uart_transmit_delay(int32_t i32Module);
void timerA0_init(void);

//void ML_Usart2_send_data(unsigned char *commandubff,unsigned char commandlengh);

#endif
 
