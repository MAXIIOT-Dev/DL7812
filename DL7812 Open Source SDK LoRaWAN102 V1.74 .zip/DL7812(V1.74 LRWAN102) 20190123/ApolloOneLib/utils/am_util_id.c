//*****************************************************************************
//
//! @file am_util_id.c
//!
//! @brief Identification of the Ambiq Micro device.
//!
//! This module contains functions for run time identification of Ambiq Micro
//! devices.
//
//*****************************************************************************

//*****************************************************************************
//
// Copyright (c) 2017, Ambiq Micro
// All rights reserved.
// 
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// 
// 1. Redistributions of source code must retain the above copyright notice,
// this list of conditions and the following disclaimer.
// 
// 2. Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
// 
// 3. Neither the name of the copyright holder nor the names of its
// contributors may be used to endorse or promote products derived from this
// software without specific prior written permission.
// 
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//
// This is part of revision 1.2.6 of the AmbiqSuite Development Package.
//
//*****************************************************************************
#include <stdint.h>
#include <stdbool.h>
#include "am_util_id.h"


//*****************************************************************************
//
// Globals.
//
//*****************************************************************************
//
// Strings for use with pui8VendorName.
//
const uint8_t g_DeviceNameApollo[]     = "Apollo";
const uint8_t g_DeviceNameApollo2[]    = "Apollo2";
const uint8_t g_ui8VendorNameAmbq[]    = "AMBQ";
const uint8_t g_ui8VendorNameUnknown[] = "????";
const uint8_t g_ui8DeviceNameUnknown[] = "Unknown device";

//*****************************************************************************
//
//! @brief Device identification.
//!
//! @param psIDDevice - ptr to a device ID structure (am_util_id_t*) to be
//! filled in by the function.
//!
//! This function provides additional information about the currently running
//! Ambiq Micro MCU device.
//!
//! @returns The ui32Device value, which is a value corresponding to the
//! device type.
//
//*****************************************************************************
uint32_t
am_util_id_device(am_util_id_t *psIDDevice)
{
    uint32_t ui32PN;

    //
    // Go get all the device (hardware) info from the HAL
    //
    am_hal_mcuctrl_device_info_get(&psIDDevice->sMcuCtrlDevice);

    //
    // Device identification
    //
    ui32PN = psIDDevice->sMcuCtrlDevice.ui32ChipPN  &
             AM_UTIL_MCUCTRL_CHIP_INFO_PARTNUM_PN_M;

    if ( (psIDDevice->sMcuCtrlDevice.ui32JedecCID   == 0xB105100D)          &&
         (psIDDevice->sMcuCtrlDevice.ui32JedecJEPID == 0x0000009B)          &&
         ((psIDDevice->sMcuCtrlDevice.ui32JedecPN & 0xF00) != 0xE00) )
    {
        //
        // It's Ambiq Micro, set up the VENDORID.
        //
        psIDDevice->pui8VendorName = g_ui8VendorNameAmbq;
    }
    else
    {
        //
        // For now, set it as unknown vendor, but we may change it later.
        //
        psIDDevice->pui8VendorName = g_ui8VendorNameUnknown;
    }

    if ( psIDDevice->sMcuCtrlDevice.ui32VendorID ==
         (('A' << 24) | ('M' << 16) | ('B' << 8) | ('Q' << 0)) )
    {
        //
        // VENDORID is AMBQ, so set the string pointer.
        //
        psIDDevice->pui8VendorName = g_ui8VendorNameAmbq;
    }

    if ( ((psIDDevice->sMcuCtrlDevice.ui32JedecPN & 0x0F0) == 0x0E0)        &&
         ( ui32PN == AM_UTIL_MCUCTRL_CHIP_INFO_PARTNUM_APOLLO ) )
    {
        psIDDevice->ui32Device = AM_UTIL_ID_APOLLO;
        psIDDevice->pui8DeviceName = g_DeviceNameApollo;

        //
        // Force the vendor name for Apollo, which did not support VENDORID.
        //
        psIDDevice->pui8VendorName = g_ui8VendorNameAmbq;
    }
    else if ( ((psIDDevice->sMcuCtrlDevice.ui32JedecPN & 0x0F0) == 0x0D0)   &&
              ( ui32PN == AM_UTIL_MCUCTRL_CHIP_INFO_PARTNUM_APOLLO2 ) )
    {
        psIDDevice->ui32Device = AM_UTIL_ID_APOLLO2;
        psIDDevice->pui8DeviceName = g_DeviceNameApollo2;
    }
    else
    {
        psIDDevice->ui32Device = AM_UTIL_ID_UNKNOWN;
        psIDDevice->pui8DeviceName = g_ui8DeviceNameUnknown;
    }

    return psIDDevice->ui32Device;
}
