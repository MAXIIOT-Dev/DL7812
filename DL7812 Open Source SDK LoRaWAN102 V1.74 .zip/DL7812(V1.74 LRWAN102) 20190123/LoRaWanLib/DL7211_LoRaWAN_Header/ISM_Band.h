#ifndef __ISM_BAND_H__
#define __ISM_BAND_H__

/* USER CODE BEGIN Includes */
#include "board.h"
#include "LoRaMac.h"

/* USER CODE END Includes */



/* USER CODE BEGIN Private defines */

#define ISMBandNum		7


typedef enum
{
	EU863_870 = 0,
	US902_928,
    AS923,
	CN779_787,
	CN470_510,
	EU433,
	CUSTOMIZE,
}ISM_Band_TYPE_t;


typedef struct{
    uint8_t DATARATES[16];
    uint8_t BANDWIDTH[16];
		uint8_t DATARATEOFFSETS[8][6];
    ChannelParams_t CHANNEL[3];
		Rx2ChannelParams_t	RX2CHANNEL;		//��ֱ�Ӹ�ֵ
}ISM_BAND_PM_t;



/* USER CODE END Private defines */


/* Private variables ---------------------------------------------------------*/
extern ISM_Band_TYPE_t	ISM_Band_TYPE;
extern ISM_BAND_PM_t	ISM_BAND_PM[ISMBandNum];

/* Private function prototypes -----------------------------------------------*/
extern void Default_CH_Update(void);



#endif
