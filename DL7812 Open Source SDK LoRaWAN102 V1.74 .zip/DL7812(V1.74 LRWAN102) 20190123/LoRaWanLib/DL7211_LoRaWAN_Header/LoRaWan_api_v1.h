#ifndef __LORAWAN_API_V1_H
#define __LORAWAN_API_V1_H

/* USER CODE BEGIN Includes */
#include "board.h"

/* USER CODE END Includes */


/* USER CODE BEGIN Private defines */



typedef enum
{
	NONE = 0,
	TXDONE,
	TXTIMEOUT,
	RXDONE,
	RXTIMEOUT,
	RXERROR,
	ACK_RECEIVE,
	ACK_UNRECEIVE,
	CMD_RECEIVE,
	OTAA_JOINOK,
}LoRaWanFLAG_Type_t;

typedef enum
{
	SendOK  = 0,
	CHANNEL_BUSY = -1,
	NO_FREE_CHANNEL = -2,
	NOBUF = -3,
}SendReturn_Type_t;

typedef enum
{
	STATUS_OK  = 0,
	STATUS_BUSY,
	STATUS_NO_NETWORK_JOINED,
	STATUS_LENGTH_ERROR,
	STATUS_SERVICE_UNKNOWN,
	STATUS_DEVICE_OFF = 6,
}OTAAReturn_Type_t;

typedef enum
{
	OFF = 0,
	ON,
}ChannelState_Type_t;

typedef enum
{
	CH0=0,CH1,CH2,CH3,CH4,CH5,CH6,CH7,CH8,CH9,CH10,CH11,CH12,CH13,CH14,CH15
}ChannelNum_Type_t;

typedef enum{
	AUTO,
	MANUAL,
	PASSTHROUGH,
}LoRaSendMode_t;

typedef enum{
	ABP_JOIN = 0,
	OTAA_JOIN,
}LoRaAutoJoinMode_t;

typedef enum{
	Confrim = 0,
	Unconfrim,
}LoRaWanFrameMode_t;


typedef enum{
	NoPrint = 0,
	Print,
}OriginalRxFramePrint_t;

typedef struct{
    int16_t rssi;
    uint8_t snr;
    uint8_t port;
    uint16_t size;
    uint8_t buf[256];
}LoRaWanRxInfo_Type_t;


typedef struct{
  uint8_t Seconds;
	uint8_t Minutes;
	uint8_t Hours; 
	uint8_t WeekDay;
	uint8_t Date;
	uint8_t Month;
	uint8_t Year;
}LoRaWanRTCTime_Type_t;


/* USER CODE END Private defines */


/* Private variables ---------------------------------------------------------*/
extern uint16_t LoRaWanFlag;
extern LoRaWanRxInfo_Type_t LoRaWanRxInfo;
extern uint8_t AutoSendFrame[256];
extern uint8_t AutoSendLen;
extern uint8_t OTAA_Rejoin_flag;

/* Private function prototypes -----------------------------------------------*/

//----------------weak function begin----------------------//
extern void LoRaWanSetRTCAlarm(uint16_t rtcAlarmDays, uint8_t rtcAlarmHours, uint8_t rtcAlarmMinutes, uint8_t rtcAlarmSeconds);
extern LoRaWanRTCTime_Type_t LoRaWanGetRTCTime(void);
extern void lora_printf(char *fmt, ...);
extern void at_printf(char *fmt, ...);
//----------------weak function end----------------------//

extern void LoRaWanSetSaveConfig( void );
extern void LoRaWanSetRestoreFactory( void );
extern void LoRaWanGetDeviceEUI( uint8_t DEUI[8] );
extern void LoRaWanSetADDR( uint32_t Addr );
extern uint32_t LoRaWanGetADDR( void );
extern void LoRaWanSetAppEUI( uint8_t AEUI[8] );
extern void LoRaWanGetAppEUI( uint8_t AEUI[8] );
extern void LoRaWanSetAppKey( uint8_t AK[16] );
extern void LoRaWanGetAppKey( uint8_t AK[16] );
extern void LoRaWanSetAppSKey( uint8_t ASK[16] );
extern void LoRaWanGetAppSKey( uint8_t ASK[16] );
extern void LoRaWanSetNetworkSKey( uint8_t NSK[16] );
extern void LoRaWanGetNetworkSKey( uint8_t NSK[16] );
extern void LoRaWanGetRSSI_SNR( int16_t *rssi, uint8_t *snr);
extern void LoRaWanSetTxPower( uint8_t TxPower);
extern uint8_t LoRaWanGetTxPower( void );
extern void LoRaWanSetJoinAcceptDelay1( uint32_t delayus );
extern uint32_t LoRaWanGetJoinAcceptDelay1( void );
extern void LoRaWanSetJoinAcceptDelay2( uint32_t delayus );
extern uint32_t LoRaWanGetJoinAcceptDelay2( void );
extern void LoRaWanSetReceiveDelay1( uint32_t delayus );
extern uint32_t LoRaWanGetReceiveDelay1( void );
extern uint32_t LoRaWanGetReceiveDelay2( void );
extern uint32_t LoRaWanGetUpLinkCounter( void );
extern uint32_t LoRaWanGetDownLinkCounter( void );
extern bool LoRaWanSetISMBand( uint8_t ISMBand );
extern uint8_t LoRaWanGetISMBand( void );
extern void LoRaWanSetChannelMask( uint16_t ChMask[6] )	;
extern uint16_t* LoRaWanGetChannelMask( void );
extern bool LoRaWanSetChannelState(uint8_t StartCH_Num, uint8_t EndCH_Num, ChannelState_Type_t state);
extern bool LoRaWanAddChannel(uint8_t CH_Num, ChannelParams_t param);
extern bool LoRaWanDelChannel(uint8_t CH_Num);
extern bool LoRaWanSetChannelDR( uint8_t TxChDR );
extern uint8_t LoRaWanGetChannelDR( void );
extern bool LoRaWanSetRx1DrOffset(uint8_t offset);
extern uint8_t LoRaWanGetRx1DrOffset(void);
extern uint8_t LoRaWanSetCustomDRList( uint8_t DR, uint8_t SF, uint16_t BW, uint8_t DrOffset);
extern bool LoRaWanSetClass( DeviceClass_t Class );
extern uint8_t LoRaWanGetClass( void );
extern bool LoRaWanSetADR( bool enable );
extern bool LoRaWanGetADR( void );
extern bool LoRaWanSetRXWIN2( Rx2ChannelParams_t param );
extern Rx2ChannelParams_t LoRaWanGetRXWIN2(void);
extern uint8_t LoRaWanSendBuf( uint8_t type, uint8_t *buf, int size, int retry);
extern bool LoRaWanSendLinkCheckReq(void);
extern OTAAReturn_Type_t LoRaWanSendOTAAJoinReq( uint8_t *devEui, uint8_t *appEui, uint8_t *appKey );
extern void LoRaWanSetABPJoinReq( uint32_t netID, uint32_t devAddr, uint8_t *nwkSKey, uint8_t *appSKey );
extern bool LoRaWanGetNetworkJoined(void);
extern uint8_t LoRaGetJoinState(void);
extern uint16_t LoRaWanCheckFlag(void);
extern bool LoRaWanSetSendMode(LoRaSendMode_t Mode);
extern LoRaSendMode_t LoRaWanGetSendMode( void );
extern bool LoRaWanSetSendPort(uint8_t Port);
extern uint8_t LoRaWanGetSendPort( void );
extern void LoRaWanSetAutoJoinMode( LoRaAutoJoinMode_t mode );
extern LoRaAutoJoinMode_t LoRaWanGetAutoJoinMode( void );
extern void LoRaWanSetFrameType( LoRaWanFrameMode_t mode );
extern LoRaWanFrameMode_t LoRaWanGetFrameType( void );
extern void LoRaWanSetAutoSendFrame( uint8_t Buf[], uint8_t BufLen);
extern void LoRaWanSetNSMI( uint8_t enable );
extern uint8_t LoRaWanGetNSMI( void );
extern void LoRaWanSetNNMI( uint8_t enable );
extern uint8_t LoRaWanGetNNMI( void );
extern void LoRaWanSetPNMI( uint8_t enable );
extern uint8_t LoRaWanGetPNMI( void );
extern void PointToPointSend(uint32_t freq, uint8_t DR, uint8_t power, uint8_t *buff, uint8_t len);


#endif
