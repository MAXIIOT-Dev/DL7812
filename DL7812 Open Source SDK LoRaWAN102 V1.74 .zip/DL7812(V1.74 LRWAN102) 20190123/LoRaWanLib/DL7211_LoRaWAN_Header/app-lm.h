/*
    _/_/_/    _/_/_/    _/_/_/  _/_/_/  _/      _/    _/_/_/  _/    _/  _/_/_/_/
   _/    _/    _/    _/          _/    _/_/    _/  _/        _/    _/  _/
  _/_/_/      _/      _/_/      _/    _/  _/  _/  _/  _/_/  _/_/_/_/  _/_/_/
 _/    _/    _/          _/    _/    _/    _/_/  _/    _/  _/    _/  _/
_/    _/  _/_/_/  _/_/_/    _/_/_/  _/      _/    _/_/_/  _/    _/  _/
    (C)2015 RisingHF, all rights reserved.

Description: Application LoRaWAN stack

*/
#ifndef __APP_LM_H
#define __APP_LM_H

#include <stdint.h>
#include "board.h"
#include "radio.h"
#include "LoRaMac.h"
#include "LoRaMac-api-v3.h"

//��������ʹ��,��������0
#define	USE_BOOST		1		//���������USE_BOOST����ʹ��BOOST�������


#define AT_MODULE_PORT				(9)
#define AESKEY_LEN                  (16)


extern uint8_t OVER_THE_AIR_ACTIVATION;
extern uint8_t DevEui[];
//extern uint8_t NwkSKey[];
//extern uint8_t AppSKey[];
//extern uint8_t AppEui[];
//extern uint8_t AppKey[];
//extern uint32_t DevAddr;


//#define APP_PORT                                        (2)

extern uint32_t TxCountS;
//#define APP_TX_DUTYCYCLE_RND                            (1000000)   // 1s
#define APP_TX_DUTYCYCLE_RND                            (1000)   // 1ms

typedef enum{
	IDLE,
	BUSY,
	DONE,
}LoRaStatus_t;

typedef enum{
	CONFIRMED,
	UNCONFIRMED
}LoRaFrameType_t;

typedef enum{
	INVALID,
	RECEIVED,
	UNRECEIVED,
}LoRaTxAckReceived_t;

typedef enum{
    LORAMAC_NWKSKEY=0,
    LORAMAC_APPSKEY=1,
    LORAMAC_APPKEY=2,
}LoRaMacKey_t;

typedef struct{
    int16_t rssi;
    uint8_t snr;
    uint8_t win;
    uint8_t port;
    uint16_t size;
    uint8_t buf[256];
}LoRaMacRxInfo;

typedef enum{
    LM_STA_TXDONE,
    LM_STA_RXDONE,
    LM_STA_RXTIMEOUT,
    LM_STA_ACK_RECEIVED,
    LM_STA_ACK_UNRECEIVED,
    LM_STA_CMD_RECEIVED,
}lm_evt_t;

typedef enum {
    DEVICE_STATE_INIT,
    DEVICE_STATE_JOIN,
    DEVICE_STATE_SEND,
    DEVICE_STATE_CYCLE,
    DEVICE_STATE_SLEEP
}eDeviceState;



// ʱ��ṹ��  
typedef struct{  
		uint8_t second;  
		uint8_t minute;  
		uint8_t hour;  
		uint8_t day;  
		uint8_t month;  
		uint16_t year;  
}DATETIME;  


extern eDeviceState DeviceState;
extern TimerEvent_t TxNextPacketTimer;
extern bool NextTx;
extern LoRaMacRxInfo RxInfo;
extern uint8_t Tx_Channel;
extern uint8_t LinkCheckReq;
extern DATETIME LoRaWanRTC;
extern uint32_t GreenTime;
extern uint32_t AlarmGreenTime;
extern uint8_t DevEui[8];




typedef void (*lm_callback_t) (lm_evt_t lm_evt, LoRaMacRxInfo *msg);

void app_lm_init(lm_callback_t cb);
int app_lm_send( LoRaFrameType_t type, uint8_t *buf, int size, int retry);

uint32_t app_lm_get_devaddr(void);

int LoRaMacSetKey(LoRaMacKey_t key_type, uint8_t *key);
int LoRaMacGetKey(LoRaMacKey_t key_type, uint8_t *key);

void OnTxNextPacketTimerEvent( void );
void app_lm_cb (lm_evt_t evt, LoRaMacRxInfo *msg);



//------------------User Need Function Begin------------------------//
//��������ִ��
void LoRaMAC_Process(void);
//1sִ��һ��
void TxNextPacket_Process(void);
//1msִ��һ��
void LoRaWanRTCProgress(void);
//------------------User Need Function End------------------------//

#endif
