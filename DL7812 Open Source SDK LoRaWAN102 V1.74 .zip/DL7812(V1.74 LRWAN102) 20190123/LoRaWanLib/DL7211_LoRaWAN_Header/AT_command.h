#ifndef __AT_COMMAND_H
#define __AT_COMMAND_H

#include "board.h"

//-----------------------��Ҫ���ݲ�ͬMCU�޸�------------------------------//

typedef enum{
	USE_EEPROM = 0,
	USE_Flash,
}StorageMethod_t;

//----------LoRaWan Code begin---------------------//
static StorageMethod_t StorageMethod = USE_Flash;

//���ʹ��USE_Flash�洢��DEFLORACONFADDR��UpdateFlagAddr��FFWFlagAddrҪ�ڲ�ͬ��ҳ�С�
#define DEFLORACONFADDR  (( 256 * 1024 ) + (6 * AM_HAL_FLASH_PAGE_SIZE))
static uint32_t UpdateFlagAddr	= (( 256 * 1024 ) + (4 * AM_HAL_FLASH_PAGE_SIZE));			//EEPROM ������±�־:0x5555������Ҫ���г�����£��õ�ַҪ��IAPд��һ��
static uint32_t FFWFlagAddr = (( 256 * 1024 ) + (5 * AM_HAL_FLASH_PAGE_SIZE));					//EEPROM �״�д���־:0x5555������д��


typedef struct FLoraConfAddr
{
	uint32_t FDevAddr;
	uint32_t FNwkSKeyAddr;
	uint32_t FAppSKeyAddr;
	uint32_t FAppKeyAddr;
	uint32_t FAppEUIAddr;
	uint32_t FTxDRAddr;
	uint32_t FADRAddr;
	uint32_t FISMBandAddr;
	uint32_t FTxpowerAddr;
	uint32_t FActWayAddr;
	uint32_t FConfFlagAddr;
	uint32_t FClassAddr;
	uint32_t FNSMIAddr;
    uint32_t FNNMIAddr;
    uint32_t FPNMIAddr;
	uint32_t FDebugAddr;
	uint32_t FChannelMaskAddr;
	uint32_t FSendPortAddr;
	uint32_t FCUSSFAddr;
	uint32_t FCUSBWAddr;
	uint32_t FRxWIN2Addr;
	uint32_t FChannelsAddr;
}LoraConfAddr;

typedef struct FLoraConfig
{
	uint32_t DevAddr;
	uint8_t NwkSKey[16];
	uint8_t AppSKey[16];
	uint8_t AppKey[16];
	uint8_t AppEui[8];
	uint32_t TXDR;
	uint32_t ADR;						
	uint32_t ISMBand;		
	uint32_t TXPower;	
	uint32_t ActivationWay;
	uint32_t ConfFlag;
	uint32_t CurClass;	
	uint32_t NSMI;
    uint32_t NNMI;
    uint32_t PNMI;
	uint32_t Debug;
	uint16_t ChannelMask[6];
	uint8_t SendPort;
	uint8_t CUSSF[16];
	uint8_t CUSBW[16];
	uint32_t RxWIN2[7];			//Freq+DR ; 6��ISM Band
	uint32_t Channels[16];		//Freq+DRMax+DRMin; CH0-15; CUSTOM
}LoraConfig;

static LoraConfAddr DefLoraConfAddr = 
{
	DEFLORACONFADDR+4*4,		//����ǰ�漸����־λ
	DEFLORACONFADDR+5*4,
	DEFLORACONFADDR+9*4,
	DEFLORACONFADDR+13*4,
	DEFLORACONFADDR+17*4,
	DEFLORACONFADDR+19*4,		//TXDR
	DEFLORACONFADDR+20*4,		//ADR
	DEFLORACONFADDR+21*4,		//ISMBand
	DEFLORACONFADDR+22*4,		//TXPower
	DEFLORACONFADDR+23*4,		//ActivationWay
	DEFLORACONFADDR+24*4,		//ConfFlag
	DEFLORACONFADDR+25*4,		//CurClass
	DEFLORACONFADDR+26*4,		//NSMI
    DEFLORACONFADDR+27*4,		//NNMI
    DEFLORACONFADDR+28*4,		//PNMI
	DEFLORACONFADDR+29*4,		//Debug
	DEFLORACONFADDR+30*4,		//ChannelMask[6]
	DEFLORACONFADDR+33*4,		//SendPort
	DEFLORACONFADDR+34*4,		//CUSSF[16]
	DEFLORACONFADDR+38*4,		//CUSBW[16]
	DEFLORACONFADDR+42*4,		//RxWIN2[7]
	DEFLORACONFADDR+49*4,		//Channels[16]
};

#define DownstreamCacheNum  5 
#define PointstreamCacheNum  3 

extern LoraConfig DefLoraConfig;
extern LoraConfig TempLoraConfig;
extern LoraConfAddr DefLoraConfAddr;

extern uint8_t DeviceName[7];
extern uint8_t DeviceRev[13];
extern uint8_t DeviceRevDate[11];

extern uint32_t Uplink_Error_Counter;
extern uint32_t Uplink_NoACK_Counter;
extern uint8_t Downstream[DownstreamCacheNum][242]; //Cache up to 5 downstream buffer.
extern uint8_t DownstreamLen[DownstreamCacheNum];
extern uint8_t DownstreamOldestNum; 
extern uint8_t DownstreamCounter;
extern uint8_t Pointstream[PointstreamCacheNum][242]; //Cache up to 3 Pointstream buffer.
extern uint8_t PointstreamLen[PointstreamCacheNum];
extern uint8_t PointstreamOldestNum; 
extern uint8_t PointstreamCounter;

extern uint8_t senddata[250];
extern uint16_t sendlen;
extern uint8_t ATSendFlag;
extern uint8_t ATSCFGFlag;
extern uint8_t ATSleepFlag;

//-------------------__weak function begin------------------------//
extern void MCU_RESET(void);
extern void FLASH_Program(uint32_t Address, uint32_t Data);
extern void FLASH_Lock(void);
extern void FLASH_Unlock(void);
extern void FLASH_Erase_ADDRInPage(uint32_t Adrr);
extern void BoardGetUniqueId( uint8_t *id );
extern void SleepTimerStart( uint32_t Period_S );
extern void SleepTimerStop( void );
extern void LoRaWanTimerStart( void );
extern void LoRaWanTimerStop( void );
extern void EnterSleepMode( void );
extern void SleepTimerAwake(void);
//-------------------__weak function end------------------------//

extern uint8_t FrameRec(uint8_t Rxdata, char OutATBuf[],uint16_t *OutATLen);
extern void FrameRecTiming(void);
extern uint8_t AT_Comd_Decode(char ATBuf[], uint16_t ATLen);
extern uint8_t PTFrameRec(uint8_t Rxdata, uint8_t PTBuf[],uint16_t *PTLen);
extern void LoraConfigInit(LoraConfig *TempLoraConfig, LoraConfig DefLoraConfig);
extern void LoraConfSave(LoraConfig LoraConfig);

//------------------User Need Function Begin------------------------//
extern void UART_ATCommand_Process(uint8_t RxData);
//------------------User Need Function End------------------------//

#endif
