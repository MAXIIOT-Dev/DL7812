#ifndef __XS508_H
#define __XS508_H

#include "Simulate_I2C.h"
#include "lib_XS508.h"
#include <stdio.h>		//printf
#include <stdlib.h>		//srand rand
#include "time.h"
/*********************************************
//   XS508���� 
//  IN:  16BYTE KEY & 16BYTE ID
// OUT:  0->PASS 
//      -1->I2C WRITE OR READ ERROR
//   other->NG
*********************************************/

extern uint16_t Srandseed;
extern uint16_t xs_tick;
extern unsigned char XS508_DAT[16];

extern int HI2C_write( unsigned char  address,  unsigned char *buffer,   int     maximum_length, int    *actual_length) ;
extern int HI2C_read( unsigned char  address,  unsigned char *buffer, int     maximum_length, int    *actual_length) ;
extern void XS508_delay_ms(int D_TIME);
extern int get_xs_srand(void);

//extern int XS508_Handshake(unsigned char *XS508_16B_Ukey,unsigned char *XS508_16B_ID);

int XS508_Main(void);
  
#endif
