#ifndef __SIMULATE_H__
#define __SIMULATE_H__

/* USER CODE BEGIN Includes */
#include "mcu_head.h"

/* USER CODE END Includes */



/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */


/* Private variables ---------------------------------------------------------*/



/* Private function prototypes -----------------------------------------------*/
//---------------weak����-------------------
extern void I2C_SCL_H(void);
extern void I2C_SCL_L(void);
extern void I2C_SDA_H(void);
extern void I2C_SDA_L(void);
extern uint8_t I2C_SDA_Read(void);


uint8_t I2C_ISendB(uint8_t sla,uint8_t suba,uint8_t c);
uint8_t I2C_IRvcB(uint8_t sla,uint8_t suba, uint8_t *rdata);
uint8_t I2C_ISeqSendB(uint8_t sla,uint8_t suba,uint8_t *wdata, int datalen);
uint8_t I2C_ISeqRvcB(uint8_t sla,uint8_t suba, uint8_t *rdata, int datalen);

extern int E2ROM_Write_Byte(unsigned char address, unsigned char Reg_W_Address, unsigned char *write_data);
extern int E2ROM_Read_Byte(unsigned char address, unsigned char Reg_R_Address, unsigned char *read_data);
extern int E2ROM_Write_Sequ(unsigned char address, unsigned char Reg_W_Address, unsigned char *write_data,int maximum_length);
extern int E2ROM_Read_Sequ(unsigned char address, unsigned char Reg_R_Address, unsigned char *read_data ,int maximum_length);

#endif
